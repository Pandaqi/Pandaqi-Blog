# v1.5.0
## 01/06/2016

1. [](#bugfix)
    * Fixed the filters blueprint by adding category to it

# v1.4.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.3.0
## 07/21/2015

2. [](#new)
    * Redirects to random page by default
    
# v1.2.1
## 06/16/2015

2. [](#new)
    * Changelog started

