---
title: 'One Week Games'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

This category contains everything related to my "One Week Games".

With these projects, I try to force myself to create and finish a whole game within a week. It usually works exceptionally well, because it keeps me motivated, without increasing the scope of the games so far that they just become too complicated.