---
title: '[Devlog] Pizza Peers'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

Explains how I made Pizza Peers, a game you can control with your _smartphone_, playable right in the browser. It was made using the Phaser.io library (game engine) and the peer-to-peer javascript library. The devlog basically explains everything I did, including images and code samples.