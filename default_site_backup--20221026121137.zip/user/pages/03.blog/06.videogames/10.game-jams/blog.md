---
title: 'Game Jams'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

This is an overview page for all articles related to _game jams_. That will mostly be _devlogs_ for games I made for a specific jam, but might also be general advice, anecdotes or news about jams.