---
title: 'Good Friends are Hard to Find'
published: false
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

Contains everything about my game ["Good Friends are Hard to Find"](https://pandaqi.com/good-friends-are-hard-to-find)! A hide-and-seek party game (on the computer) for all ages, all player counts, all situations, literally everyone and everything.

This means a _devlog_ (where each "mode" or "minigame" has its own article), a general article about why I keep creating _local_ multiplayer games (instead of online, which many people ask for), and updates/results on the game as time goes on.