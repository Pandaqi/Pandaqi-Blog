---
title: 'Wondering Witches (Part 3)'
thumbnail_media: ../../wondering-witches-header.webp
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
taxonomy:
    tag:
        - 'technical devlog'
---

Welcome to part 3 of my Technical Devlog for the game Wondering Witches!

You can find the first part here: [Technical Devlog WW](http://pandaqi.com/blog/wondering-witches/technical-devlog-wondering-witches/wondering-witches-part-1)

The Importance of Feedback
--------------------------

Great, our potion evaluator can check if this is the winning potion and
execute all necessary effects.

### Feedback Level \#1

But one big step is missing: players test a potion to **gather
information**. The website should give them some feedback. This feedback
should be useful and informative, but not *too* useful. That would make
the game too easy or straightforward.

At first, I created a category of **investigative effects** to solve
this problem. It was a list of \~20 effects which simply *reported*
information about the potion.

For example, the **Detective** tells you the secret number of a *random
ingredient* from the potion. Or the **Inspector** tells you how many
ingredients had one (or more) special effects in this potion.

These effects were extremely useful and effective! Whenever they were
used, I would just save phrases like "Detective says 4", and print that
to the screen (in a random order).<script src="https://gist.github.com/Pandaqi/ea0ecb60b8eb4c56148d0e755e06e46c.js"></script>

### Feedback Level \#2

But it was not enough. When it comes to puzzle games, it's never good to
actively *withhold* 90% of the information from the player. That just
makes it an impossible problem, not a fun puzzle.

So I decided to give feedback about *any effect*. If an effect was not
investigative, it would simply say something like "Effect X was
encountered" or "Effect X was present". Knowing that an effect was
present, is very valuable information (and easy to code). Not knowing
precisely what the effect did, made it into a challenging puzzle.

### Feedback Level \#3

But there was **another level** of feedback I was forgetting. What if
players didn't figure out the solution? What if players lost the game?
Surely, they would want to know the actual solution.

So I added a button that, when clicked, printed the solution to the
screen. (Each ingredient, plus their number, plus any effects.) In
hindsight, it was absolutely stupid to forget the inclusion of this
button. I'm happy I remembered to do so.

Of course, I was worried about people accidentally clicking it. Or being
too tempted to click it. So I made it smaller, moved it away from the
interface, colored it red, and clearly marked it as a danger zone. It's
worked perfectly so far.

### Feedback Level \#3

But wait, is that ... **another level of feedback** I am forgetting?
Sure it is!

This realization only came to me after numerous playtests. (Which tells
us, again, that playtesting your game is always the way to go.)

At the start of the game, players were just ... really unsure about what
to do. They had absolutely *zero* information, so what does it matter
which ingredients we grow? What does it matter which potion we try?

I changed this to give the players a flying start. When you generate a
puzzle, it gives you one clue "for free". It might say something like
"Free Advice: Parsley is NOT number 1" or "Bonus Tip: Either Parsley,
Sage or Thyme is a DECOY"

This gets you started! You already know some ingredients you want to
test (or avoid). Additionally, it makes the game a little easier. As it
stands, the game is quite hard, so by framing this information as a
"free clue", I can sneakily balance the game a bit more.<script src="https://gist.github.com/Pandaqi/b095019eb83253a56246e0bc2e4815ca.js"></script>

*Remark:* additionally, I changed something about board generation to
fix this problem. I'll talk about it more later, but here's the general
idea. At first, when I generated a starting setup, I placed random
ingredients in *gardens*. Now I changed that so it also places some
ingredients within *cauldrons*. Why? Because this means you can already
test a potion within one or two turns, giving the game a quicker start.

**What's the conclusion?** When it comes to games, the mantra is
"feedback, feedback, feedback" Both boardgames and video games.

This devlog continues at part 4: [Devlog WW (Part 4)](http://pandaqi.com/blog/wondering-witches/technical-devlog-wondering-witches/wondering-witches-part-4)