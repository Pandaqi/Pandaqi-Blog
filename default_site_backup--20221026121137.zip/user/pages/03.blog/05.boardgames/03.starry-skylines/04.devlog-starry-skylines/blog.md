---
title: '[Devlog] Starry Skylines'
content:
    items: '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

The _devlog_ for [Starry Skylines](https://pandaqi.com/starry-skylines) (3 parts)