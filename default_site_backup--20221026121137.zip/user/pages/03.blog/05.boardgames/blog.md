---
title: Boardgames
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

This page contains all devlogs related to _boardgames_. 

This includes my hybrid games: boardgames with a digital component, usually my game studio website. (Unless the game has so many digital elements that I'd rather call it a digital game or _videogame_.)