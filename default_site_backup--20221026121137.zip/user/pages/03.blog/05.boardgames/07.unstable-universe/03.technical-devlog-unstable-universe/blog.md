---
title: '[Technical Devlog] Unstable Universe'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

Contains the _technical devlog_ for Unstable Universe, the first ever boardgame where you must **cut** into the board! Explains the technical details behind implementing a website that can generate **random boards**, which are still balanced, good-looking, and functional.