---
title: '[Devlog] Timely Transports'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

The _devlog_ for Timely Transports, a hybrid board-computer game about simultaneously moving vehicles around a randomly generated jungle.