---
title: '[Technical Devlog] One Pizza The Puzzle'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

Contains the _technical devlog_ for "One Pizza The Puzzle". This game has randomly generated boards (press a button, get a board, print it, play!). Which is awesome, but also _a lot of work_ to get right. The boards need to look good, be balanced, include any possible expansions/player counts/difficulty settings.

As such, this devlog isn't done at the moment. If you really want to know how I made this, send me an email to say "hey, finish that thing now!" ;)