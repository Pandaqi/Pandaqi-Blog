---
title: 'One Pizza the Puzzle'
media_order: one-pizza-the-puzzle.jpg
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

Here you can find the devlogs for my _One Paper Game_ called [**One Pizza the Puzzle**](https://pandaqi.com/one-pizza-the-puzzle)

It contains a _devlog_ (with 7 parts) and a _technical devlog_ (to be determined ...)