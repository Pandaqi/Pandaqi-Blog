---
title: 'Reviews & Tutorials'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

This page contains my reviews and tutorials.

With reviews, I give my thoughts about a game or software/hardware used during game creation. I don't write a lot of these ... yet.

With tutorials, I explain how to use things (which I've perhaps reviewed), or give standalone tutorials about whatever I think is interesting to know. (I think reading my devlogs is how you can actually learn a lot of wisdom about game creation, the tutorials are just a side dish.)