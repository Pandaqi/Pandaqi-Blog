---
title: Specials
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

This page contains special projects that don't fit in the other categories.

These are usually _bundles_ (so multiple games within the same theme/world/mechanic/project) or games with such a unique setup that I'm not sure what to call the project. Perhaps "experimental" is the word here.