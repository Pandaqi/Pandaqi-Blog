---
title: News
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

This page contains all the news and announcements I make on the blog. (Which rarely happens, as announcements are usually made elsewhere or not at all.)