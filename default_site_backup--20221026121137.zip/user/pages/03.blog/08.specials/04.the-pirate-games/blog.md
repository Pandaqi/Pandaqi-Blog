---
title: 'The Pirate Games'
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
---

"The Pirate Games" are a collection of games with the same core mechanic and theme. (Which I, very creatively, called _the pirate games_)

These are "deduction games": all players get unique hints about some puzzle (say, where a treasure is located) and must figure out the hints of the other players by, well, playing the game in a smart way.