# Pandaqi Blog Theme

The **Pandaqi Blog** Theme is for [Grav CMS](http://github.com/getgrav/grav).  This README.md file should be modified to describe the features, installation, configuration, and general usage of this theme.

## Description

Very basic blogging theme for Pandaqi
